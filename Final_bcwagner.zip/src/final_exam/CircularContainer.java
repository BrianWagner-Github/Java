package final_exam;

class CircularContainer extends Container {
	double radius;

	CircularContainer(double height, double radius) {
		super(height);
		this.radius = radius;
	}

	double getTopArea() {
		return Math.PI * radius * radius;
	}

	double getTopPerimeter() {
		return 2.0 * Math.PI * radius;
	}
}