package final_exam;

class RectangularContainer extends Container {
	double width;
	double length;

	RectangularContainer(double height, double width, double length) {
		super(height);
		this.width = width;
		this.length = length;
	}

	double getTopArea() {
		return width * length;
	}

	double getTopPerimeter() {
		return 2.0 * (width + length);
	}
}