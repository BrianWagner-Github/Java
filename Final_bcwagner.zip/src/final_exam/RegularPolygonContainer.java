package final_exam;

class RegularPolygonContainer extends Container {
	double side;
	int numSides;

	RegularPolygonContainer(double height, double side, int numSides) {
		super(height);
		this.side = side;
		this.numSides = numSides;
	}

	double getTopArea() {
		return numSides * side * side / (4 * Math.tan(Math.PI / numSides));
	}

	double getTopPerimeter() {
		return numSides * side;
	}
}