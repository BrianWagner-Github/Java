package object_oriented;
 
import java.util.Random;
import java.util.Scanner;
 
public class Hangman
{
    Scanner keyboard = new Scanner(System.in);
    Random rand = new Random();
   
    void playGame()
    {
        String topSecretWord = getNextWordToGuess();
        String newLetter;
        String userInputs = "";
        // System.out.println("The new word is " + topSecretWord); //This was to test the getNextWordToGuess method.
        do
        {
            System.out.println();
            System.out.print("Enter a single letter. Additional letters will be ignored. ");
            newLetter = keyboard.next().substring(0,1);
            System.out.println();
            // System.out.println("The letter is " + newLetter); // This was to test the substring code.
            userInputs = userInputs + newLetter;
           
        } while (!printCurrStatus(topSecretWord, userInputs));
    }
   
    boolean isIn(char c, String str)
    {
        boolean temp = false;
        int len = str.length();
        for (int i = 0; i < len; i++)
        {
            if (str.charAt(i) == c)
                temp = true;
        }
        return temp;
    }
   
    boolean printCurrStatus(String strToGuess, String userInputs)
    {
        boolean gameOver = true;  //This is set to false below in the case of even 1 missing letter
       
        System.out.println("Current Status for userInputs=" + userInputs);
       
        // System.out.print("Status of the word: ");
       
        /* The following loop checks each letter in the hidden word to see if it
         * has been guessed. If the letter has been guessed then it prints the letter;
         * otherwise, it prints an underscore.
         * It sets gameOver to false for a miss.
         */
        for (int i = 0; i < strToGuess.length(); i++)
        {
            if (isIn(strToGuess.charAt(i), userInputs))
            {
                System.out.print(" " + strToGuess.charAt(i));
            }
            else
            {
                System.out.print(" _");
                gameOver = false;
            }
        }
       
        System.out.println();
        return gameOver;
           
    }
   
    String getNextWordToGuess()
    {
        final int numOfWords = 10;
        int num = rand.nextInt(numOfWords);
        String word;
       
        switch (num)
        {
            case 0:
                word = "elephant";
                break;
            case 1:
                word = "tiger";
                break;
            case 2:
                word = "monkey";
                break;
            case 3:
                word = "baboon";
                break;
            case 4:
                word = "barbeque";
                break;
            case 5:
                word = "giraffe";
                break;
            case 6:
                word = "simple";
                break;
            case 7:
                word = "zebra";
                break;
            case 8:
                word = "porcupine";
                break;
            case 9:
                word = "aardvark";
                break;
            default:
                word = "";
                System.out.println("Uh oh. The wrong random number was generated.");
                System.exit(-1);
        }
        return word;
       
    }
   
    public static void main(String[] args)
    {
        Hangman hangman = new Hangman();
        String response = "";
        do
        {
            hangman.playGame();
            System.out.println();
            System.out.println("Congratulations! You win!");
            System.out.println();
            System.out.println("Do you want to play object oriented Hangman again? (y or n): ");
            response = hangman.keyboard.next();
        } while (response.charAt(0) == 'y' || response.charAt(0) == 'Y');
       
        System.out.println("Bye");
    }
   
}