package roman_calculator;

import java.util.*;

public class RomanCalculator
{
// scan can now be used anywhere within this class
Scanner scan = new Scanner(System.in);

// This routine either returns false if the use wants to quit,
// or it does one Roman Calculator calculation
boolean doCalculation()
{
   System.out.println("Operator: + - * / q for quit: ");
   char operator = getOperator();
   if(operator == 'q')
   {
       return false;
   }
  
   int operand1, operand2;
   System.out.println("Enter operand1: ");
   operand1 = getOperand(1);
   System.out.println("Enter operand2: ");
   operand2 = getOperand(2);
  
   int Answer = doArithmetic(operand1,operand2,operator);
   System.out.println("Answer ="+convert_to_Roman(Answer));
  
   return true;
}

// This routine prompts the user with
// Operator: + - * / q for quit
// If none of these are entered, this routine complains and
// prompts the user again. Otherwise the operator is returned.
char getOperator()
{
   String operator1;
   operator1 = scan.next();
   return operator1.charAt(0);
}

// This routine prompts the user for either operand1 or operand2
// depending on the value of which. This routine uppercases the
// input and calls convert_from_Roman to create an integer.
// If the input is invalid ( negative return from convert_from_Roman)
// then complain and prompt the user again.
int getOperand(int which)
{
   int RealValue = 0;
   if(which==1)
   {  
       String operand;
       operand = scan.next();
       RealValue = convert_from_Roman(operand.toUpperCase());
       if(RealValue < 0)
       {
           System.out.println("Error in first operand");
           RealValue=0;
       }
       return RealValue;
   }
   else
   {
       String operand;
       operand = scan.next();
       RealValue = convert_from_Roman(operand.toUpperCase());
       if(RealValue < 0)
       {
           System.out.println("Error in second operand");
           RealValue=0;
       }
       return RealValue;
   }
}


// Routine to convert an integer to a Roman Numeral String.
// When you do this routine, you might find it handy to
// create a utility routine that looks like:
// String addRomanDigit(String starting, int num, char digit)
String convert_to_Roman(int value)
{
   String s1="";
   while(value > 0)
   {
       if(value >= 1000)
       {
           s1 = s1 + "M";
           value = value-1000;
       }
       else if(value >= 500)
       {
           s1 = s1 + "D";
           value = value-500;
       }
       else if(value >= 100)
       {
           s1 = s1 + "C";
           value = value-100;
       }
       else if(value >= 50)
       {
           s1 = s1 + "L";
           value = value-50;
       }
       else if(value >= 10)
       {
           s1 = s1 + "X";
           value = value-10;
       }
       else if(value >= 5)
       {
           s1 = s1 + "V";
           value = value-5;
       }
       else if(value >= 1)
       {
           s1 = s1 + "I";
           value = value-1;
       }
       int i = 0;
   }
   s1 = s1 + "";
   return s1;
}


// Convert Roman Numeral String to an integer. If the
// Roman Numeral String is invalid, return -1.
int convert_from_Roman(String value)
{
   int sum = 0;
  
   for(int i=0; i<value.length(); i++)
   {
       if(value.charAt(i)=='M')
       {
           sum += 1000;
       }
       else if(value.charAt(i)=='D')
       {
           sum += 500;
       }
       else if(value.charAt(i)=='C')
       {
           sum += 100;
       }
       else if(value.charAt(i)=='L')
       {
           sum += 50;
       }
       else if(value.charAt(i)=='X')
       {
           sum += 10;
       }
       else if(value.charAt(i)=='V')
       {
           sum += 5;
       }
       else if(value.charAt(i)=='I')
       {
           sum += 1;
       }
       else
       {
           sum = -1;
       }
   }
  
   return sum;
}

// Perform the arithmetic indicated by the operator (+ - * /)
// and return answer
int doArithmetic(int operand1, int operand2, char operator)
{

   int result = 0;
  
   if(operator == '+')
   {
       result = operand1 + operand2;
   }
   else if(operator == '-')
   {
       result = operand1 - operand2;
   }
   else if(operator == '*')
   {
       result = operand1 * operand2;
   }
   else if(operator == '/')
   {
       result = operand1 / operand2;
   }
  
   return result;
}

public static void main(String[] args)
{
   RomanCalculator rc = new RomanCalculator();
  
   while (rc.doCalculation())
   {
       System.out.println();
   }
  
   System.out.println("Finished Roman Computations");
  
}
}