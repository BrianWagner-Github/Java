package alphabet;

public class Alphabet {

	public static void main(String[] args) { 
		int i = 97; 
		while (i < 123) { 
			String type = "is a consonant."; 
			char letter = (char)i; 
			switch (letter) {
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
                System.out.println(letter + " is a vowel.");
                break;
			} 
		System.out.println(letter + " " + type); 
		i++; 
		}  
	}
}