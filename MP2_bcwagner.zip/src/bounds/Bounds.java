package bounds;

import java.util.Scanner;

public class Bounds {

public static void main(String[] args) {

	Scanner scanner = null;

	try {

		int startingNumber, upperBound, stepSize;

		scanner = new Scanner(System.in);

		System.out.print("Enter the starting Number:");

		startingNumber = scanner.nextInt();

			System.out.print("Enter the upper bound:");

			upperBound = scanner.nextInt();

			System.out.print("Enter the step size:");

			stepSize = scanner.nextInt();

			System.out.println("startingNumber: " + startingNumber + " upperBound: " + upperBound + " stepSize: " + stepSize);

			int sequnce = 0;

			for (int i = 0, j = 1; (startingNumber + i * stepSize) < upperBound; i++, j++) {

				sequnce = startingNumber + i * stepSize;

				if (j < 10 || (j % 10) != 0)

					System.out.print(sequnce + " ");

				else

					System.out.println(sequnce);

}

} catch (Exception e) {

}

}

}