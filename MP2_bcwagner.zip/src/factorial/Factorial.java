package factorial;

import java.util.Scanner;

public class Factorial{

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		char choice = 'y';
		while(choice == 'y'||choice =='Y') {
			System.out.print("Enter in N: ");
			int n = scan.nextInt();
			System.out.println("Factorial = "+factorial(n));
			System.out.println("Do you want to continue? (y/n): ");
			choice = scan.next().charAt(0);
		}

	}

	public static int factorial(int n) {
		int product = 1;
		for(int i=1; i<=n ;i++){
			product = product * i;
	}
		return product;

	}

}