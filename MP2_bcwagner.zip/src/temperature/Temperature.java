package temperature;

import java.util.Scanner;
import java.text.DecimalFormat;

public class Temperature
{
	public static void main (String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		double centigrade;
		// while (centigrade > -100.0) {
			System.out.print("Enter a temperature in Centigrade or <= -100.0 to quit: ");
			centigrade = keyboard.nextDouble();
			double fahrenheit = 9.0/5*centigrade + 32;
		//	double totalFahrenheit = totalFahrenheit + fahrenheit;
			//double totalCentigrade = totalCentigrade + centigrade;
		//	int countUserInputs = countUserInputs +1;
			DecimalFormat df = new DecimalFormat("#.000");
			System.out.print("Temperature: " + df.format(centigrade) + " C " + df.format(fahrenheit) + " F");
		//	double averageF = totalFahrenheit/countUserInputs;
		//	double averageC = totalCentigrade/countUserInputs;
		//	break;
		 }
			//System.out.println();
			//if (centigrade <= -100.0);
		//	System.out.print("Average: Centigrade " + (averageC) + " Average: Fahrenheit " + (averageF));
	}