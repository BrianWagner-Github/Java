package newton_sqrt;

import java.util.Scanner;
public class Newton_sqrt {
    public static void main(String[] args) {
        double guess, new_guess = 0, last_guess, accuracy, n, x, absolutex;

        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter in N for Newton: ");
        n = keyboard.nextDouble();
        last_guess = n / 2;

        do {
            new_guess = last_guess - (last_guess*last_guess-n) / (2*last_guess);
            x = Math.abs(last_guess - new_guess);
            if (x < .000001) {
                break ;
            } else {
                last_guess = new_guess;
            }
        } while (n >= .00);

        System.out.println("Newton = " + new_guess);
        double mth = Math.sqrt(n);
        System.out.println("Math.sqrt = " + mth);

    }

}
