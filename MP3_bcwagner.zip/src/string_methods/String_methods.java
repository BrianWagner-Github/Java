package string_methods; 

import java.util.Scanner;

public class String_methods {

private String myStr="";

public void readString(){

Scanner s=new Scanner(System.in);

myStr=s.nextLine();

}

public void setString(String s){

myStr =s;

}

public int countOccurrences(String s){


int count = 0;

int index = 0;

while ((index = myStr.indexOf(s, index)) != -1){

index++;

count++;

}

return count;

}

public int countOccurrences(char c){


int count = 0;

for (char cc : myStr.toCharArray()) {

if (c == cc) {

count++;

}

}

return count;

}

int countUpperCaseLetters(){

int upperCase=0;

for (int k = 0; k < myStr.length(); k++) {

if (Character.isUpperCase(myStr.charAt(k))) upperCase++;

}

return upperCase;


}

int countLowerCaseLetters(){

int lowerCase=0;

for (int k = 0; k < myStr.length(); k++) {

if (Character.isLowerCase(myStr.charAt(k))) lowerCase++;

}

return lowerCase;

}

public void printCounts(String s, char c){

System.out.println("***************************************");

System.out.println("Analyzing: myStr="+myStr);

System.out.println("Number of Upper case letters="+countUpperCaseLetters());

System.out.println("Number of Lower case letters="+ countLowerCaseLetters());

System.out.println("Number of "+s + " is "+ countOccurrences(s));

System.out.println("Number of "+c + " is "+ countOccurrences(c));

}

public static void main(String[] args) {

String_methods msm = new String_methods();

msm.readString();

msm.printCounts("big", 'a');

msm.setString("Parked in a van down by the river bank .... The vanevan vanished near a lot of other vans");

msm.printCounts("van", 'a');

String_methods msm2 = new String_methods();

msm2.setString("the elephant in the room wouldn't budge");

msm2.printCounts("the", 'i');

}

}