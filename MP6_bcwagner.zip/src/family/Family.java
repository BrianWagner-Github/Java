package family;
	public class Family {
	   Person[] personInFamily;
	   int currPersonInFamily =0;

	   Family ()
	   {
	       this (10);
	   }


	   Family (int sizeOfFamily)
	   {
	       personInFamily = new Person [sizeOfFamily];

	   }

	   void printOutFamily()
	   {
	       for (int i=0; i<currPersonInFamily; i++)
	       {
	           System.out.println (personInFamily[i].toString());
	       }
	   }

	   void addPerson (Person pers)

	   {
	       if (currPersonInFamily >= personInFamily.length)
	       {
	           System.out.println ("Person not added due to size limitations " + pers.toString());
	       }
	       else
	       {
	           for (int i=0; i<currPersonInFamily; i++)
	           {
	               if (pers.equals(personInFamily[i]))
	               {
	                   System.out.println ("Duplicate not added " + pers.toString());
	                   return;
	               }  
	           }
	          
	           personInFamily [currPersonInFamily] = pers;
	           currPersonInFamily ++;
	       }
	   }
	}