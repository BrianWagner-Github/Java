package family;
public class Person
{
   private String name;
   private int age;

   public Person ()
   {
       name = "";
       age = 0;
   }

   public Person (String theName, int theAge)
   {
       if (theName ==null || theAge <=0 || theAge >= 200 )
       {
           System.out.println ("Fatal error creating the person.");
           System.exit(0);
       }
       name= theName;
       age = theAge;
   }

   public Person (Person originalObject)
   {
       name = originalObject.name;
       age = originalObject.age;
   }

   public String getName ()
   {
       return name;
   }

   public int getAge ()
   {
       return age;
   }

   public void setName (String newName)
   {
       if (newName != null && newName != "")
           name = newName;
       else
       {
           System.out.println ("Error. Improper name value.");
       }
   }

   public void setAge (int newAge)
   {
       if (newAge >0 && newAge <200)
           age= newAge;
       else
       {
           System.out.println ("Error: Improper age value. ");
           System.exit(0);
       }
   }

   public String toString ()
   {
       return (name + " " + age);
   }

   public boolean equals (Person p)
   {
       return (name.equals(p.name) && age ==p.age);   
   }


}