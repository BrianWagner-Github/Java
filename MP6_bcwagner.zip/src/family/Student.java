package family;

public class Student extends Person {

	   private String major;
	   private double gpa;

	   public Student ()
	   {
	       super();
	       major = "";
	       gpa = 0;
	   }

	   public Student (String theName, int theAge, String theMajor, double theGpa)
	   {
	       super (theName, theAge);

	       if (theMajor == null || theGpa < 0 || theGpa >4.0)
	       {
	           System.out.println ("Fatal error creating student.");
	           System.exit (0);
	       }
	       else
	       {
	           major = theMajor;
	           gpa = theGpa;
	       }
	   }

	   public Student (Student originalObject)
	   {
	       super(originalObject);
	       major= originalObject.major;
	       gpa = originalObject.gpa;
	   }

	   public String getMajor ()
	   {
	       return major;
	   }

	   public double getGpa ()
	   {
	       return gpa;
	   }

	   public void setMajor (String m)
	   {
	       if (m != null)
	           major = m;

	       else
	       {
	           System.out.println ("Please enter the right major.");
	           System.exit (0);
	       }
	   }

	   public void setGpa (double g)
	   {
	       if (g>=0 && g <=4.0)
	           gpa =g;
	       else
	       {
	           System.out.println ("Please enter the right GPA.");
	           System.exit (0);
	       }
	   }

	   public String toString ()
	   {
	       return (getName() + " " + getAge() + " " + major + " " + gpa );
	   }

	   public boolean equals (Student s)
	   {
	       return major.equals(s.getMajor()) && gpa == s.gpa && super.equals(s);
	   }

	}