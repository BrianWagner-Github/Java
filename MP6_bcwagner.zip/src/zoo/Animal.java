package zoo;

public abstract class Animal {
    private String name;
    private double weight;
    private int age;
  
    public Animal() {
        name = "";
        weight = 0;
        age = 0;
    }
  
    public Animal(String name, double weight, int age) {
        this.name = name;
        this.weight = weight;
        this.age = age;
    }
  
    public abstract String makeNoise();
  
    public double getWeight() {
        return weight;
    }
  
    public String toString() {
        return name + ", weight " + weight + ", age " + age;
    }
}