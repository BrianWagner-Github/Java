package zoo;

public class Cow extends Animal {
    private int num_spots;
   
    public Cow() {
        super();
        num_spots = 0;
    }
   
    public Cow(String name, double weight, int age, int num_spots) {
        super(name, weight, age);
        this.num_spots = num_spots;
    }
   
    @Override
    public String makeNoise() {
        return "Moooo";
    }
   
    public String toString() {
        return "Cow " + super.toString() + ". Number of spots: " + num_spots;
    }
}