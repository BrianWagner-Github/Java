package zoo;

public class Horse extends Animal {
    private double top_speed;
   
    public Horse() {
        super();
        top_speed = 0.0;
    }
   
    public Horse(String name, double weight, int age, double top_speed) {
        super(name, weight, age);
        this.top_speed = top_speed;
    }
   
    @Override
    public String makeNoise() {
        return "Whinny";
    }
   
    public String toString() {
        return "Horse " + super.toString() + ". Top speed: " + top_speed;
    }
}