package zoo;

public class Snake extends Animal {
    private int num_fangs;
   
    public Snake() {
        super();
        num_fangs = 0;
    }
   
    public Snake(String name, double weight, int age, int num_fangs) {
        super(name, weight, age);
        this.num_fangs = num_fangs;
    }
   
    @Override
    public String makeNoise() {
        return "Hisssssss";
    }
   
    public String toString() {
        return "Snake " + super.toString() + ". Number of fangs: " + num_fangs;
    }
}