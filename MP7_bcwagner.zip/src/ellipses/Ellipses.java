package ellipses;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;

public class Ellipses extends Applet{

public void paint(Graphics g){
   Color back=new Color(237,52,209);
   Color ring=new Color(75,65,211);
setForeground(back);
g.fillOval(100,100,500,300);
g.setColor(ring);
int x,y;
int w,h;
w=490;
h=290;
for(x=105,y=105;x<=490 && y<=290;x=x+5,y=y+5,w=w-10,h=h-10)
{
   g.drawOval(x,y,w,h);
}
}
}