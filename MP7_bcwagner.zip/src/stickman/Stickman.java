package stickman;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JFrame;

public class Stickman  extends JFrame {
	Stickman (String name)
        {
                super(name);
                setSize (500, 500); 
                setVisible (true);
                setDefaultCloseOperation (EXIT_ON_CLOSE);
        }
        public void paint (Graphics g)
        {
                Dimension d = getSize (); 
                g.setColor (Color.white); //white board 
                g.fillRect (0, 0, d.width, d.height); 
                g.setColor(Color. yellow);
                g.fillRect(210, 164, 40, 150); //body 
                g.fillRect(222, 147, 15, 17); //neck 
                g.fillOval (210, 110, 40, 40); //face 
                g.setColor (Color.black);
                g.fillRect (217,100, 28, 14); // hat 
                g.drawOval(210, 110, 40, 40); // line of the face 
                g.fillOval(219, 125, 4, 3); // left eye 
                g.fillOval(237, 125, 4, 3); // right eye
                g.drawLine(210, 172, 130, 180); // left arm 
                g.drawLine(250, 172, 330, 180); // right arm 
                g.drawLine (228, 132, 231, 132); // mouth 
                g.drawLine(215, 314, 205, 434); // left leg 
                g.drawLine(245, 314, 255, 434); // right leg 
                g.drawLine (207, 112, 252, 112); // line of the hat            
                g.setColor(Color. yellow);
                g.fillRect(222, 147, 15, 17); //neck 
        }
        public static void main(String[] args) {
        	Stickman  s = new Stickman  ("My First Drawing"); 
        }

}
